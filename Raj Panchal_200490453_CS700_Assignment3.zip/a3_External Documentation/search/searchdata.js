var indexSectionsWithContent =
{
  0: "3abcdgijlmnorstwy",
  1: "abcdst",
  2: "adr",
  3: "abcdgijmostwy",
  4: "abcdlmnosty",
  5: "o",
  6: "3abcs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends",
  6: "Pages"
};

