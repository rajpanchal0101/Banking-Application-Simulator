var searchData=
[
  ['isleapyear_0',['isleapyear',['../class_date.html#a9df96f29fe0085fd859e1f922a2f0f10',1,'Date::IsLeapYear(const int iYear)'],['../class_date.html#aacf4a2743d3ac09e2b23f9b7a07cd1e7',1,'Date::IsLeapYear(void) const']]]
];
