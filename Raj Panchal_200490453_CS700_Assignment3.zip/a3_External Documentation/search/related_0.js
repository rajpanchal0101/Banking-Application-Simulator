var searchData=
[
  ['operator_2b_0',['operator+',['../class_date.html#a663dc2803160d8add313f6f1baaaea1a',1,'Date::operator+'],['../class_date.html#aa73448f83b880e7dd24a95666fbf6df5',1,'Date::operator+']]],
  ['operator_2d_1',['operator-',['../class_date.html#a5d6f001b44a2e33cfc63b6cd8e638403',1,'Date::operator-'],['../class_date.html#a13b53a039912de5a24ec580fac54a496',1,'Date::operator-']]],
  ['operator_3c_3c_2',['operator&lt;&lt;',['../class_date.html#a65ff0f219c6817d3b8b6e57724dc680a',1,'Date']]],
  ['operator_3e_3e_3',['operator&gt;&gt;',['../class_date.html#a399e807597adeffa59d2a6540c7362d9',1,'Date']]]
];
