var searchData=
[
  ['name_0',['name',['../class_customer.html#a42c1c948fa0121c82b2725826d9f8300',1,'Customer::name'],['../class_application.html#a50642bd18bf5c9dae65dd37f36a01ccb',1,'Application::name']]]
];
